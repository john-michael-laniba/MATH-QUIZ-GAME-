// Toggle sign-in/sign-up
const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');
signUpButton.onclick = () => container.classList.add("right-panel-active");
signInButton.onclick = () => container.classList.remove("right-panel-active");  

// ============================================
// GOOGLE LOGIN - FIXED VERSION
// ============================================

// Parse JWT function
function parseJwt(token) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
  } catch (e) {
    console.error("Error parsing JWT:", e);
    return {
      name: "Google User",
      email: "",
      picture: ""
    };
  }
}

// Google callback function
window.handleCredentialResponse = function(response) {
  console.log("✅ Google login response received");
  
  try {
    const data = parseJwt(response.credential);
    console.log("👤 User data from Google:", data);
    
    let googleUser = {
      name: data.name || "Google User",
      email: data.email,
      picture: data.picture || "",
      googleUser: true
    };
    
    localStorage.setItem("currentUser", JSON.stringify(googleUser));
    
    let users = JSON.parse(localStorage.getItem("users")) || [];
    const existingUser = users.find(u => u.email === googleUser.email);
    
    if (!existingUser) {
      const newUser = {
        name: googleUser.name,
        email: googleUser.email,
        pass: 'google-auth',
        googleUser: true,
        created: new Date().toLocaleString()
      };
      
      users.push(newUser);
      localStorage.setItem("users", JSON.stringify(users));
      
      let history = JSON.parse(localStorage.getItem("history")) || {};
      history[googleUser.email] = [];
      localStorage.setItem("history", JSON.stringify(history));
      
      let allScores = JSON.parse(localStorage.getItem("allScores")) || {};
      allScores[googleUser.email] = [];
      localStorage.setItem("allScores", JSON.stringify(allScores));
      
      alert(`✅ Welcome ${newUser.name}! Redirecting to game...`);
    } else {
      alert(`👋 Welcome back ${googleUser.name}!`);
    }
    
    document.getElementById('container').style.display = 'none';
    document.getElementById('quiz').style.display = 'flex';
    showHome();
    
  } catch (error) {
    console.error("❌ Error in Google login:", error);
    alert("Login failed. Please try again.");
  }
};

// Initialize Google Sign-In (FIXED function name)
function initGoogleSignIn() {
  if (typeof google !== 'undefined' && google.accounts) {
    google.accounts.id.initialize({
      client_id: '723294447600-le503v7eqd8e7abpo56rofbv8dh16tt2.apps.googleusercontent.com',
      callback: window.handleCredentialResponse,
      auto_select: false,
      cancel_on_tap_outside: true,
      prompt_parent_id: 'container' // Small improvement - helps position the popup
    });
    console.log("Google Sign-In initialized");
  }
}

// Click handler for Google icons
function handleGoogleClick(e) {
  e.preventDefault();
  e.stopPropagation();
  console.log("Google icon clicked");
  
  if (typeof google !== 'undefined' && google.accounts) {
    // Ensure initialized before prompting
    initGoogleSignIn();
    // Show the sign-in prompt
    google.accounts.id.prompt();
  } else {
    alert("Google Sign-In is still loading. Please try again in a moment.");
  }
}

// Set up icon click handlers
document.addEventListener('DOMContentLoaded', function() {
  console.log("Setting up Google icons...");
  
  // Initialize Google Sign-In
  initGoogleSignIn();
  
  // Setup Google icon 1
  const googleIcon1 = document.getElementById('customGoogleBtn');
  if (googleIcon1) {
    const newIcon1 = googleIcon1.cloneNode(true);
    googleIcon1.parentNode.replaceChild(newIcon1, googleIcon1);
    newIcon1.addEventListener('click', handleGoogleClick);
  }
  
  // Setup Google icon 2
  const googleIcon2 = document.getElementById('customGoogleBtn2');
  if (googleIcon2) {
    const newIcon2 = googleIcon2.cloneNode(true);
    googleIcon2.parentNode.replaceChild(newIcon2, googleIcon2);
    newIcon2.addEventListener('click', handleGoogleClick);
  }
  
  console.log("Google icons setup complete");
});

// Auto login if user already logged in
window.addEventListener('load', function() {
  const user = JSON.parse(localStorage.getItem("currentUser"));
  if(user){
    container.style.display = 'none';
    document.getElementById('quiz').style.display = 'flex';
    showHome();
  }
});

// Sign Up
document.getElementById("signupForm").addEventListener("submit", function(e){
  e.preventDefault();
  const name = document.getElementById("signupName").value;
  const email = document.getElementById("signupEmail").value;
  const pass = document.getElementById("signupPassword").value;

  let users = JSON.parse(localStorage.getItem("users")) || [];
  if(users.some(u => u.email === email)){
    alert("Email already exists!");
    return;
  }
  users.push({name, email, pass});
  localStorage.setItem("users", JSON.stringify(users));
  alert("Account created! Please Sign In.");
  container.classList.remove("right-panel-active");
});

// Sign In
document.getElementById("signinForm").addEventListener("submit", function(e){
  e.preventDefault();
  const email = document.getElementById("signinEmail").value;
  const pass = document.getElementById("signinPassword").value;
  let users = JSON.parse(localStorage.getItem("users")) || [];
  const user = users.find(u => u.email === email && u.pass === pass);

  if(user){
    localStorage.setItem("currentUser", JSON.stringify(user));
    playLoginAnimation(() => {
      container.style.display = 'none';
      document.getElementById('quiz').style.display = 'flex';
      showUserInfo();
    });
  } else { 
    alert("Invalid email or password!");
  }
});

function showUserInfo(){
  const user = JSON.parse(localStorage.getItem("currentUser"));
  if(user){
    showHome();
  }
}

// Login animation function
function playLoginAnimation(callback){
  const anim = document.getElementById("loginAnimation");
  anim.style.display = "flex";
  anim.style.opacity = 0;
  
  setTimeout(() => { anim.style.opacity = 1; }, 50);

  setTimeout(() => {
    anim.style.opacity = 0;
    setTimeout(() => {
      anim.style.display = "none";
      if(callback) callback();
    }, 500);
  }, 2000);
}

// QUIZ LOGIC
let score=0, 
    currentQuestion=1, 
    maxQuestions=10, 
    correctAnswer, 
    minNumber=1,
    maxNumber=10, 
    mode="", 
    timeLeft=10, 
    timerInterval;

const correctMessages=["Great 🎉","Nice 😎","Wow 🔥"];
const wrongMessages=["Aww 😢","Damn 😬","Tulog na 😴"];

function startGame(selectedMode){
  mode = selectedMode;

  if(mode === "noob"){
    minNumber = 1;
    maxNumber = 50;
  }

  if(mode === "expert"){
    minNumber = 50;
    maxNumber = 200;
  }

  if(mode === "god"){
    minNumber = 100;
    maxNumber = 300;
  }

  if(mode === "hacker"){
    minNumber = 500;
    maxNumber = 1000;
  }

  document.getElementById("modeName").textContent = mode.toUpperCase();
  document.getElementById("modeBoxes").classList.add("hidden");
  document.getElementById("gameArea").classList.remove("hidden");

  score = 0;
  currentQuestion = 1;

  generateQuestion();
}

function generateQuestion(){
  if(currentQuestion>maxQuestions){ endGame(); return; }

  const num1 = Math.floor(Math.random() * (maxNumber - minNumber + 1)) + minNumber;
  const num2 = Math.floor(Math.random() * (maxNumber - minNumber + 1)) + minNumber;
  const op = selectedOperation;

  if(op==="/"){
    const divisor = Math.floor(Math.random() * (maxNumber - minNumber + 1)) + minNumber;
    const quotient = Math.floor(Math.random() * 10) + 1;
    const dividend = divisor * quotient;
    
    correctAnswer = quotient;
    document.getElementById("question").textContent=`${dividend} ÷ ${divisor}`;
  } else {
    switch(op){
      case "+": correctAnswer=num1+num2; document.getElementById("question").textContent=`${num1} + ${num2}`; break;
      case "-": correctAnswer=num1-num2; document.getElementById("question").textContent=`${num1} - ${num2}`; break;
      case "*": correctAnswer=num1*num2; document.getElementById("question").textContent=`${num1} × ${num2}`; break;
    }
  }

  generateAnswers(); startTimer();
}

function generateAnswers(){
  const answersDiv = document.getElementById("answers");
  answersDiv.innerHTML = "";

  const options = new Set();
  options.add(correctAnswer);

  while(options.size < 4){
    let wrong = correctAnswer + Math.floor(Math.random() * 20) - 10;
    if(wrong !== correctAnswer){
      options.add(wrong);
    }
  }

  [...options]
    .sort(() => Math.random() - 0.5)
    .forEach(val => {
      const btn = document.createElement("button");
      btn.textContent = val;
      btn.classList.add("answer-btn"); // ✅ Important
      btn.onclick = () => checkAnswer(val, btn); // Pass button reference
      answersDiv.appendChild(btn);
    });
}

function startTimer(){
  timeLeft=10; document.getElementById("timer").textContent=timeLeft;
  clearInterval(timerInterval);
  timerInterval=setInterval(()=>{
    timeLeft--; document.getElementById("timer").textContent=timeLeft;
    if(timeLeft<=0){ clearInterval(timerInterval); checkAnswer(null); }
  },1000);
}

function checkAnswer(selected, btn){
  clearInterval(timerInterval);
  const feedback = document.getElementById("feedback");

  // Remove previous glow from all buttons
  document.querySelectorAll(".answer-btn").forEach(b => {
    b.classList.remove("correct", "wrong");
  });

  if(selected === correctAnswer && selected !== null){ 
    score++; 
    // Feedback message for correct
    const messages = ["Great 🎉","Nice 😎","Wow 🔥"];
    feedback.textContent = messages[Math.floor(Math.random()*messages.length)];
    feedback.className = "feedback correct"; 
    if(btn) btn.classList.add("correct"); // green glow
  } else { 
    // Feedback message for wrong
    const messages = ["Aww 😢","Damn 😬","Tulog na 😴"];
    feedback.textContent = messages[Math.floor(Math.random()*messages.length)];
    feedback.className = "feedback wrong"; 
    if(btn) btn.classList.add("wrong"); // red glow
  }
  // Update score
  document.getElementById("score").textContent = score;

  // Timeout bago next question
  setTimeout(()=>{ 
    feedback.textContent = ""; // reset feedback
    document.querySelectorAll(".answer-btn").forEach(b => {
      b.classList.remove("correct", "wrong"); // reset glow
    });
    saveHistory(selected);
    currentQuestion++; 
    generateQuestion(); 
  },800);
}

function saveHistory(selected){
  let history = JSON.parse(localStorage.getItem("history")) || {};
  const user = JSON.parse(localStorage.getItem("currentUser"));

  if(!user) return;

  if(!history[user.email]){
    history[user.email] = [];
  }

  history[user.email].push({
    question: document.getElementById("question").textContent,
    selected: selected,
    correct: correctAnswer,
    result: selected === correctAnswer ? "Correct" : "Wrong",
    date: new Date().toLocaleString()
  });

  localStorage.setItem("history", JSON.stringify(history));
}

function showLeaderboard(){
  let allScores = JSON.parse(localStorage.getItem("allScores")) || {};
  let ranking = [];

  // Loop sa bawat user
  for(let email in allScores){
    let scores = allScores[email];
    let bestScoreObj = scores.reduce((prev, curr) => (curr.score > prev.score ? curr : prev), {score:0});
    ranking.push({
      email: email,
      score: bestScoreObj.score,
      max: 10, // total questions
      date: bestScoreObj.date || ''
    });
  }

  // Sort by score descending
  ranking.sort((a,b) => b.score - a.score);

  let html = "<h1>LEADERBOARD</h1>";

  ranking.forEach((r,i)=>{
    let cardClass = "leaderboard-card"; // default

    if(i === 0) cardClass += " top1";
    else if(i === 1) cardClass += " top2";
    else if(i === 2) cardClass += " top3";

    html += `
      <div class="${cardClass}">
        #${i+1} | ${r.email} | Score: <b>${r.score}/${r.max}</b>
      </div>
    `;
  });

  document.getElementById("mainContent").innerHTML = html;
}

function endGame(){
  clearInterval(timerInterval);

  document.getElementById("gameArea").classList.add("hidden");
  document.getElementById("gameOver").classList.remove("hidden");

  document.getElementById("finalScore").textContent = score;
  document.getElementById("finalMode").textContent = mode.toUpperCase();

  let allScores = JSON.parse(localStorage.getItem("allScores")) || {};
  const user = JSON.parse(localStorage.getItem("currentUser"));

  if(user){ 
    if(!allScores[user.email]){
      allScores[user.email] = [];
    }

    allScores[user.email].push({
      score: score,
      mode: mode,
      date: new Date().toLocaleString()
    });

    localStorage.setItem("allScores", JSON.stringify(allScores));
    displayAllScores(); 
  }
}

function backToModes(){
  document.getElementById("gameOver").classList.add("hidden");
  document.getElementById("gameArea").classList.add("hidden");
  document.getElementById("modeBoxes").classList.remove("hidden");
  document.getElementById("operationBoxes").classList.add("hidden");

  currentQuestion = 1;
  score = 0;
}

function displayAllScores(){
  const display = document.getElementById("scoreBoard");
  let allScores = JSON.parse(localStorage.getItem("allScores")) || {};
  const user = JSON.parse(localStorage.getItem("currentUser"));

  if(!user){
    display.innerHTML = "<div>Please login first.</div>";
    return;
  }

  if(Array.isArray(allScores)){
    localStorage.removeItem("allScores");
    display.innerHTML = "<div>Old score format cleared. Play a game!</div>";
    return;
  }

  if(!allScores[user.email] || allScores[user.email].length === 0){
    display.innerHTML = "<div>No scores yet.</div>";
    return;
  }

  let scores = allScores[user.email];
  let html = "";

  scores.slice().reverse().forEach((s, index) => {
    html += `
      <div style="margin-bottom:8px;">
        <b>#${scores.length - index}</b> |
        Mode: <b>${s.mode.toUpperCase()}</b> |
        Score: <b>${s.score}/10</b> 
        <span style="font-size:12px;color:#ccc;">(${s.date})</span>
      </div>
    `;
  });

  display.innerHTML = html;
}

function logout(){
  localStorage.removeItem("currentUser");
  document.getElementById("quiz").style.display = "none";
  container.style.display = "flex";
  document.getElementById("signinForm").reset();
  document.getElementById("signupForm").reset();
  document.getElementById("gameArea").classList.add("hidden");
  document.getElementById("gameOver").classList.add("hidden");
  document.getElementById("modeBoxes").classList.remove("hidden");
}

function showHome(){
  const user = JSON.parse(localStorage.getItem("currentUser"));
  if(!user) return;
  
  document.getElementById("sidebarUsername").textContent = user.name;

  document.getElementById("mainContent").innerHTML = `
    <div style="text-align: center; padding: 40px;">
      <h1 style="font-size:40px;">WELCOME 👋</h1>
      <h2 style="font-size:28px; color: white;">${user.name}</h2>
      ${user.picture ? `<img src="${user.picture}" style="width:100px;height:100px;border-radius:50%;margin:20px;">` : ''}
      <p style="margin-top:20px; color: white;">Select GAME from the sidebar to start playing.</p>
    </div>
  `;
}

function showGameMechanics(){
  document.getElementById("mainContent").innerHTML = `
    <h1>🎮 Game Mechanics</h1>
    <div style="background:#fff;padding:30px;border-radius:15px;margin-top:20px;max-width:700px;">
      <ul style="line-height:2; font-size:18px;">
        <li>10 Questions per game</li>
        <li>Each question has 10 seconds timer</li>
        <li>+1 point for correct answer</li>
        <li>No negative points</li>
        <li>Quit game saves partial score</li>
      </ul>
    </div>
  `;
}

function showStats(){
  const user = JSON.parse(localStorage.getItem("currentUser"));
  let allScores = JSON.parse(localStorage.getItem("allScores")) || {};

  let totalGames = 0;
  let bestScore = 0;
  let totalScore = 0;
  let averageScore = 0;
  let accuracy = 0;

  if(user && allScores[user.email]){
    const scores = allScores[user.email];

    totalGames = scores.length;

    bestScore = Math.max(...scores.map(s => s.score));

    totalScore = scores.reduce((sum, s) => sum + s.score, 0);

    averageScore = (totalScore / totalGames).toFixed(1);

    accuracy = ((totalScore / (totalGames * 10)) * 100).toFixed(1);
  }

  document.getElementById("mainContent").innerHTML = `
    <h1>📊 Your Stats</h1>

    <div style="background:#111;color:#fff;padding:40px;border-radius:20px;margin-top:30px;max-width:600px;">

      <h2>Total Games Played</h2>
      <h1 style="font-size:50px;">${totalGames}</h1>

      <h2>Best Score</h2>
      <h1 style="font-size:50px;">${bestScore}/10</h1>

      <h2>Average Score</h2>
      <h1 style="font-size:50px;">${averageScore}</h1>

      <h2>Accuracy</h2>
      <h1 style="font-size:50px;">${accuracy}%</h1>

    </div>
  `;
}

function showHistory(){
  const user = JSON.parse(localStorage.getItem("currentUser"));
  let allScores = JSON.parse(localStorage.getItem("allScores")) || {};

  if(!user){
    document.getElementById("mainContent").innerHTML = "<h2>Please login first.</h2>";
    return;
  }

  let html = `<h1>Your Game History</h1>`;

  if(!allScores[user.email] || allScores[user.email].length === 0){
    html += "<p>No scores yet.</p>";
  } else {
    let scores = allScores[user.email];
    html += `<div style="background:rgba(0,0,0,0.3);padding:20px;border-radius:15px;max-height:400px;overflow-y:auto;">`;
    scores.slice().reverse().forEach((s, index) => {
      const status = s.partial ? "(Quit Game)" : "";
      html += `
        <div style="background:#fff;padding:15px;margin-bottom:10px;border-radius:10px;">
          <b>#${scores.length - index}</b> |
          Mode: <b>${s.mode.toUpperCase()}</b> |
          Score: <b>${s.score}/10</b> ${status}<br>
          <span style="font-size:12px;color:gray;">${s.date}</span>
        </div>
      `;
    });
    html += `</div>`;
  }

  document.getElementById("mainContent").innerHTML = html;
}

function showGameMenu(){
  document.getElementById("mainContent").innerHTML = `
    <h1>Select Difficulty</h1>
    <div id="modeBoxes" class="grid">
    <div class="card" onclick="selectMode('noob')">NOOB 🐣</div>
    <div class="card" onclick="selectMode('expert')">EXPERT 🧠</div>
    <div class="card" onclick="selectMode('god')">GOD 👑</div>
    <div class="card" onclick="selectMode('hacker')">HACKER 🕶️</div>
  </div>
    <div id="operationBoxes" class="hidden">
      <h2>Choose Operation</h2>
      <div class="grid">
        <div class="card" onclick="startGameWithOperation('+')">ADDITION➕</div>
        <div class="card" onclick="startGameWithOperation('-')">SUBTRACTION➖</div>
        <div class="card" onclick="startGameWithOperation('*')">MULTIPLICATION➖</div>
        <div class="card" onclick="startGameWithOperation('/')">DIVISION➗</div>
      </div>
      <button onclick="backToModeSelection()" style="margin-top:20px;padding:10px 20px;border:none;border-radius:10px;background:#222;color:#fff;cursor:pointer;">⬅ Back</button>
    </div>
    <div id="gameArea" class="hidden">
      <div class="dashboard">
        <div>Mode: <span id="modeName"></span></div>
        <div>Score: <span id="score">0</span></div>
        <div>Time: <span id="timer">10</span></div>
      </div>
      <button onclick="openQuitConfirm()" style="margin:15px 0;padding:8px 20px;border:none;border-radius:10px;background:#ff4d4d;color:#fff;font-weight:bold;cursor:pointer;">❌ Quit Game</button>
      <div class="question" id="question"></div>
      <div id="answers"></div>
      <div id="feedback"></div>
    </div>
    <div id="gameOver" class="hidden">
      <h2>GAME OVER</h2>
      <p>Mode: <span id="finalMode"></span></p>
      <p>Your Score: <span id="finalScore"></span></p>
      <button onclick="backToModes()">Play Again</button>
    </div>
  `;
}

let selectedModeGlobal = "";
let selectedOperation = "";
let confirmAction = "";

function selectMode(mode){
  selectedModeGlobal = mode;
  document.getElementById("modeBoxes").classList.add("hidden");
  document.getElementById("operationBoxes").classList.remove("hidden");
}

function closeConfirm(){
  document.getElementById("confirmModal").classList.add("hidden");
}

function openLogoutConfirm(){
  document.getElementById("confirmTitle").textContent = "Logout Account";
  document.getElementById("confirmText").innerHTML = `Are you sure you want to logout?<br>You will need to login again.`;
  document.getElementById("confirmModal").classList.remove("hidden");
  confirmAction = "logout";
}

function confirmStartGame(){
  playClickSound();
  document.getElementById("confirmModal").classList.add("hidden");

  if(confirmAction === "start"){
    document.getElementById("operationBoxes").classList.add("hidden");
    document.getElementById("gameArea").classList.remove("hidden");
    startGame(selectedModeGlobal);
  }

  if(confirmAction === "quit"){
    clearInterval(timerInterval);
    const user = JSON.parse(localStorage.getItem("currentUser"));
    if(user && score > 0){
      let allScores = JSON.parse(localStorage.getItem("allScores")) || {};
      if(!allScores[user.email]) allScores[user.email] = [];
      allScores[user.email].push({
        score: score,
        mode: selectedModeGlobal,
        date: new Date().toLocaleString(),
        partial: true
      });
      localStorage.setItem("allScores", JSON.stringify(allScores));
    }
    score = 0;
    currentQuestion = 1;
    document.getElementById("gameArea").classList.add("hidden");
    document.getElementById("modeBoxes").classList.remove("hidden");
  }

  if(confirmAction === "logout"){
    localStorage.removeItem("currentUser");
    document.getElementById("quiz").style.display = "none";
    container.style.display = "flex";
    document.getElementById("signinForm").reset();
    document.getElementById("signupForm").reset();
  }

  confirmAction = "";
}

function openQuitConfirm(){
  document.getElementById("confirmTitle").textContent = "Quit Game";
  document.getElementById("confirmText").innerHTML = `Are you sure you want to quit?<br>Your current progress will be lost.`;
  document.getElementById("confirmModal").classList.remove("hidden");
  confirmAction = "quit";
}

function playClickSound(){
  const audio = new Audio("https://www.soundjay.com/buttons/sounds/button-09.mp3");
  audio.play();
}

function backToModeSelection(){
  document.getElementById("operationBoxes").classList.add("hidden");
  document.getElementById("modeBoxes").classList.remove("hidden");
}

function startGameWithOperation(op){
  selectedOperation = op;
  let operationName = "";
  if(op === "+") operationName = "ADDITION";
  if(op === "-") operationName = "SUBTRACTION";
  if(op === "*") operationName = "MULTIPLICATION";
  if(op === "/") operationName = "DIVISION";

  document.getElementById("confirmTitle").textContent = "Start Game";
  document.getElementById("confirmText").innerHTML = `Difficulty: <b>${selectedModeGlobal.toUpperCase()}</b><br>Operation: <b>${operationName}</b>`;
  document.getElementById("confirmModal").classList.remove("hidden");
  confirmAction = "start";
}

// Password validation with popup
document.addEventListener('DOMContentLoaded', function() {
  const passwordInput = document.getElementById('signupPassword');
  const requirementsPopup = document.getElementById('passwordRequirements');
  
  if (passwordInput && requirementsPopup) {
    passwordInput.addEventListener('focus', function() {
      requirementsPopup.classList.remove('hidden');
    });
    
    document.addEventListener('click', function(event) {
      if (!passwordInput.contains(event.target) && !requirementsPopup.contains(event.target)) {
        requirementsPopup.classList.add('hidden');
      }
    });
    
    passwordInput.addEventListener('input', function() {
      const password = this.value;
      const hasLength = password.length >= 6;
      const hasUppercase = /[A-Z]/.test(password);
      const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
      
      const reqLength = document.getElementById('reqLength');
      const reqUppercase = document.getElementById('reqUppercase');
      const reqSymbol = document.getElementById('reqSymbol');
      
      if (reqLength) {
        reqLength.innerHTML = hasLength ? '✅ 6 characters minimum' : '❌ 6 characters minimum';
        reqLength.style.color = hasLength ? '#00C851' : 'white';
      }
      
      if (reqUppercase) {
        reqUppercase.innerHTML = hasUppercase ? '✅ 1 uppercase letter (A-Z)' : '❌ 1 uppercase letter (A-Z)';
        reqUppercase.style.color = hasUppercase ? '#00C851' : 'white';
      }
      
      if (reqSymbol) {
        reqSymbol.innerHTML = hasSymbol ? '✅ 1 symbol (!@#$%^&*)' : '❌ 1 symbol (!@#$%^&*)';
        reqSymbol.style.color = hasSymbol ? '#00C851' : 'white';
      }
      
      if (password.length > 0) {
        if (hasLength && hasUppercase && hasSymbol) {
          passwordInput.classList.remove('invalid');
          passwordInput.classList.add('valid');
        } else {
          passwordInput.classList.remove('valid');
          passwordInput.classList.add('invalid');
        }
      } else {
        passwordInput.classList.remove('valid', 'invalid');
      }
    });
  }
});

